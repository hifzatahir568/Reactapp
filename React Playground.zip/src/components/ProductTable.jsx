import React from "react";

const ProductTable = ({ products }) => {
  return (
    <table className="product-table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Price</th>
          <th>Rating</th>
          <th>Review Count</th>
          <th>About</th>
          <th>Product URL</th>
        </tr>
      </thead>
      <tbody>
        {products.map((product, index) => (
          <tr key={index}>
            <td>{product.title}</td>
            <td>{product.price || "N/A"}</td>
            <td>{product.rating || "N/A"}</td>
            <td>{product.review_count || "N/A"}</td>
            <td>{product.about_this_item}</td>
            <td>
              <a href={product.url} target="_blank" rel="noopener noreferrer">
                View Product
              </a>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ProductTable;
